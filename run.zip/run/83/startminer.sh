./hellminer -c stratum+tcp://ap.luckpool.net:3956 -u RCnC82ZM2Va8U4Xa2EpSsfVcZLA7V4C6Qs.RDP -p x --cpu 83
